import customtkinter as ctk

class Menu(ctk.CTk):
    
    def __init__(self):
        super().__init__()
        
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        
        self.title('Ritmo e Espada')
        self.geometry('800x520')
        
        self.play_button = ctk.CTkButton(
            master=self,
            text='JOGAR'
        )
        
        self.settings_button = ctk.CTkButton(
            master=self,
            text='CONFIGURAÇES'
        )
        
        self.quit_button = ctk.CTkButton(
            master=self,
            text='QUIT'
        )
        
        self.mainloop()